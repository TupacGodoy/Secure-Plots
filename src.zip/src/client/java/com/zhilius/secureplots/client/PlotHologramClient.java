package com.zhilius.secureplots.client;

import com.zhilius.secureplots.plot.PlotData;
import com.zhilius.secureplots.plot.PlotSize;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

import java.util.*;

public class PlotHologramClient {

    public record HologramEntry(PlotData data, BlockPos pos, long expiresAt) {}
    public static final List<HologramEntry> active = new ArrayList<>();

    private static Matrix4f projMatrix = null;
    private static Matrix4f viewMatrix = null;
    private static Vec3d    lastCamPos = Vec3d.ZERO;

    public static void register() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            projMatrix = new Matrix4f(ctx.projectionMatrix());
            Quaternionf rot = new Quaternionf(ctx.camera().getRotation());
            // conjugate = inverse rotation = transforms world-space to camera-space
            viewMatrix = new Matrix4f().rotate(rot.conjugate(new Quaternionf()));
            lastCamPos = ctx.camera().getPos();
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (projMatrix == null || viewMatrix == null) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            long now = System.currentTimeMillis();
            active.removeIf(e -> e.expiresAt() < now);

            for (HologramEntry entry : active) {
                BlockPos pos = entry.pos();
                double wx = pos.getX() + 0.5 - lastCamPos.x;
                double wy = pos.getY() + 2.5 - lastCamPos.y;
                double wz = pos.getZ() + 0.5 - lastCamPos.z;

                float[] screen = project(wx, wy, wz, mc);
                if (screen == null) continue;

                drawPanel(drawContext, mc, screen[0], screen[1], entry.data());
            }
        });
    }

    public static void show(PlotData data, BlockPos pos, long durationMs) {
        // Disabled — handled by server-side TextDisplayEntity
    }

    public static void hide(BlockPos pos) { active.removeIf(e -> e.pos().equals(pos)); }
    public static void clear() { active.clear(); }

    private static float[] project(double wx, double wy, double wz, MinecraftClient mc) {
        // Transform world-relative position into camera space
        Vector4f v = new Vector4f((float)wx, (float)wy, (float)wz, 1f);
        viewMatrix.transform(v);

        // If behind camera, don't show
        if (v.z > 0) return null;

        projMatrix.transform(v);
        if (v.w <= 0) return null;

        float ndcX =  v.x / v.w;
        float ndcY = -v.y / v.w;

        // Only show if within screen bounds (with small margin)
        if (ndcX < -1f || ndcX > 1f || ndcY < -1f || ndcY > 1f) return null;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        return new float[]{
            (ndcX + 1f) / 2f * sw,
            (ndcY + 1f) / 2f * sh
        };
    }

    private static void drawPanel(DrawContext ctx, MinecraftClient mc,
                                   float cx, float cy, PlotData data) {
        List<String> lines = buildLines(data);
        int lineH = mc.textRenderer.fontHeight + 2;
        int maxW  = 0;
        for (String line : lines) maxW = Math.max(maxW, mc.textRenderer.getWidth(line));

        int padX = 8, padY = 6;
        int pw = maxW + padX * 2;
        int ph = lines.size() * lineH + padY * 2;
        int px = (int)(cx - pw / 2f);
        int py = (int)(cy - ph / 2f);

        float[] bc    = tierColor(data.getSize().tier);
        float   pulse = 0.7f + 0.3f * (float) Math.sin(System.currentTimeMillis() * 0.003);
        int     a     = 140;
        int     ba    = (int)(pulse * 220);

        ctx.fill(px, py, px+pw, py+ph, color(8, 8, 20, a));

        int br = (int)(bc[0]*255), bg2 = (int)(bc[1]*255), bb = (int)(bc[2]*255);
        ctx.fill(px+2, py+2,    px+pw-2, py+3,    color(br, bg2, bb, ba));
        ctx.fill(px+2, py+ph-3, px+pw-2, py+ph-2, color(br, bg2, bb, ba));

        int ty = py + padY;
        for (String line : lines) {
            ctx.drawText(mc.textRenderer, line, px + padX, ty, color(255, 255, 255, a), false);
            ty += lineH;
        }
    }

    private static int color(int r, int g, int b, int a) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static List<String> buildLines(PlotData data) {
        List<String> lines = new ArrayList<>();
        String name = (data.getPlotName() != null && !data.getPlotName().isBlank())
                ? data.getPlotName().toUpperCase() : "PARCELA PROTEGIDA";
        lines.add("§6§l" + name);
        lines.add("§8────────────────");
        lines.add("§7Dueño:   §f" + data.getOwnerName());
        lines.add("§7Nivel:   §b" + data.getSize().displayName);
        lines.add("§7Tamaño:  §b" + data.getSize().radius + "×" + data.getSize().radius);
        String members = data.getMembers().isEmpty() ? "§7Ninguno" : "§a" + data.getMembers().size();
        lines.add("§7Miembros: " + members);
        lines.add("§8────────────────");
        PlotSize next = data.getSize().next();
        if (next != null) lines.add("§e⬆ §7Siguiente: §b" + next.displayName);
        else              lines.add("§6★ §eNivel Máximo");
        lines.add("§8────────────────");
        lines.add("§e» §7Usá el §6Plano §7para gestionar");
        return lines;
    }

    private static float[] tierColor(int tier) {
        return switch (tier) {
            case 0  -> new float[]{1.0f, 0.55f, 0.05f};
            case 1  -> new float[]{1.0f, 0.85f, 0.00f};
            case 2  -> new float[]{0.1f,  0.90f, 0.20f};
            case 3  -> new float[]{0.15f, 0.95f, 1.00f};
            case 4  -> new float[]{0.6f,  0.20f, 0.80f};
            default -> new float[]{1.0f,  1.00f, 1.00f};
        };
    }
}
